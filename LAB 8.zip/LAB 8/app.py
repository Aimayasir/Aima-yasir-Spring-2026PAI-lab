from flask import Flask, render_template, request, jsonify
import requests

# Creating our Flask app
app = Flask(__name__)

# Home page route
@app.route('/')
def home():
    return render_template('index.html')

# Weather data fetching route
@app.route('/getweather')
def fetch_weather():
    city_name = request.args.get('city', 'Lahore')   # Default Lahore

    # Step 1: Get latitude and longitude of the city
    geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={city_name}&count=1"
    geo_response = requests.get(geo_url).json()

    if not geo_response.get('results'):
        return jsonify({"error": "Sorry, city not found. Please try another name."})

    location = geo_response['results'][0]

    # Step 2: Get weather using lat and lon
    weather_url = "https://api.open-meteo.com/v1/forecast"
    
    params = {
        "latitude": location['latitude'],
        "longitude": location['longitude'],
        "current": "temperature_2m,relative_humidity_2m,wind_speed_10m",
        "daily": "temperature_2m_max,temperature_2m_min",
        "timezone": "auto",
        "forecast_days": 7
    }

    weather_response = requests.get(weather_url, params=params).json()

    # Preparing data to send to frontend
    weather_info = {
        "city": location['name'],
        "current_temp": round(weather_response['current']['temperature_2m']),
        "humidity": weather_response['current']['relative_humidity_2m'],
        "wind_speed": round(weather_response['current']['wind_speed_10m'], 1),
        "forecast": []
    }

    # Adding 7 days forecast
    for i in range(7):
        weather_info["forecast"].append({
            "day": i + 1,
            "max_temp": round(weather_response['daily']['temperature_2m_max'][i]),
            "min_temp": round(weather_response['daily']['temperature_2m_min'][i])
        })

    return jsonify(weather_info)


if __name__ == '__main__':
    app.run(debug=True)