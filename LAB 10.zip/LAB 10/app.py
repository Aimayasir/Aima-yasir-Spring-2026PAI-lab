from flask import Flask, render_template, request, jsonify

app = Flask(__name__)


def chatbot_response(user_input):
    user_input = user_input.lower()

    if "hello" in user_input or "hi" in user_input:
        return "Hello! How can I help you with admissions?"

    elif "fee" in user_input:
        return "The admission fee is approximately 50,000 PKR per semester."

    elif "admission" in user_input:
        return "Admissions are open from August to September."

    elif "program" in user_input:
        return "We offer BSCS, BSIT, BBA, and AI programs."

    elif "deadline" in user_input or "last date" in user_input:
        return "The last date to apply is 30th September."

    else:
        return "Sorry, I didn't understand. Try asking about fee, programs, or deadlines."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def get_bot_response():
    user_text = request.form["msg"]
    return chatbot_response(user_text)

if __name__ == "__main__":
    app.run(debug=True)