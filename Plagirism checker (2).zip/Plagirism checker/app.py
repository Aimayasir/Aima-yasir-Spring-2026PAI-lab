from flask import Flask, render_template, request
from sentence_transformers import SentenceTransformer
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import os

app = Flask(__name__)

# Model load
model = SentenceTransformer('paraphrase-MiniLM-L6-v2')

def clean_text(text):
    return text.lower().strip()

def load_documents():
    folder = 'dataset'
    documents = []
    filenames = []
    if os.path.exists(folder):
        for filename in os.listdir(folder):
            if filename.endswith('.txt'):
                filepath = os.path.join(folder, filename)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                    if content:
                        documents.append(content)
                        filenames.append(filename)
    
    
    if not documents:
        documents = ["Default sample text for testing."]
        filenames = ["sample_document.txt"]
    
    return documents, filenames

all_docs, doc_names = load_documents()
doc_embeddings = model.encode(all_docs)

@app.route('/', methods=['GET', 'POST'])
def home():
    similarity = None
    best_doc = None
    details = None
    error = None
    user_text = None

    if request.method == 'POST':
        user_text = request.form.get('text', '').strip()
        
        file = request.files.get('file')
        if file and file.filename.endswith('.txt'):
            user_text = file.read().decode('utf-8').strip()
        
        if not user_text:
            error = "Please enter text or upload a .txt file."
        else:
            # Calculate similarity
            query_embedding = model.encode([user_text])
            similarities = cosine_similarity(query_embedding, doc_embeddings)[0]
            
            max_sim = float(np.max(similarities)) * 100
            best_idx = int(np.argmax(similarities))
            
            similarity = round(max_sim, 2)
            best_doc = doc_names[best_idx]
            
            details = []
            for i, score in enumerate(similarities):
                details.append({
                    'document': doc_names[i],
                    'score': round(float(score) * 100, 2)
                })

    return render_template('index.html', 
                           similarity=similarity,
                           best_match=best_doc,
                           details=details,
                           error=error,
                           user_text=user_text)

if __name__ == '__main__':
    print("App starting on http://127.0.0.1:5000")
    app.run(debug=True)